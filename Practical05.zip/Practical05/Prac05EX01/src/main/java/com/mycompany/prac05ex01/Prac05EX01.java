
package com.mycompany.prac05ex01;

public class Prac05EX01 
{

    public static void main(String[] args)
    {
        IntefaceImplemented i1=new IntefaceImplemented ();
        i1.display();
    }
}
