
package com.mycompany.labquestion1;

abstract class Container 
{
    public  abstract double volume();
    
}
