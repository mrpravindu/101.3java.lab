
package com.mycompany.prac05ex02;

public class Priest implements Speaker
{
    public void speak()
    {
        System.out.println("Hello, I am a Priest");
    }
}
