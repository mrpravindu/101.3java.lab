
package com.mycompany.prac05ex01;

public interface MyFirstInterface 
{
    //Q01
    //Without public static final keyword
    //int x=5;
    
    //With public static final keyword
    public static final int x=5;
    
    //Q02
    //Without abstract method
    //void display ();
    
    //With abstract method
    abstract void display();
    
    //declaring abstract methods with or without the abstract key word does not have the    difference
    
}
