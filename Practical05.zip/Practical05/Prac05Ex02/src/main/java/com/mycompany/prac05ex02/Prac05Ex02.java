
package com.mycompany.prac05ex02;

public class Prac05Ex02
{

    public static void main(String[] args)
    {
        Politician p1=new Politician();
        p1.speak();
        
        Priest pr1=new Priest();
        pr1.speak();
        
        Lecturer l1=new Lecturer();
        l1.speak();
    }
}
