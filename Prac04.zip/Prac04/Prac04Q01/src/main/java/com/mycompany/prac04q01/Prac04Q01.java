
package com.mycompany.prac04q01;

public class Prac04Q01
{

    public static void main(String[] args) 
    {
        
    }
}
