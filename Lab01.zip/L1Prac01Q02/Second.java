public class Second
{
	public static void main(String[] args)
		{
			System.out.println("ravindu pathum");
			System.out.println("computer science");
		}
}