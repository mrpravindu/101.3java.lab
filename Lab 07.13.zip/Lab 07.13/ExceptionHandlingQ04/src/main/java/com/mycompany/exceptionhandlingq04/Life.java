
package com.mycompany.exceptionhandlingq04;

public abstract class Life 
{
    
}
