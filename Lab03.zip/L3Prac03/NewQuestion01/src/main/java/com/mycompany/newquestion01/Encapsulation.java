
package com.mycompany.newquestion01;

public class Encapsulation 
{
    private String name;
    private int age;
    private float salary;
    
    public void setName(String name)
    {
        this.name=name;
    }
    public String getName()
    {
        return name;
    }
    
    public void setAge(int age)
    {
        this.age=age;
    }
    public int getAge()
    {
        return age;
    }
    
    public void setSalary(float salary)
    {
        this.salary=salary;
    }
    public float getSalary()
    {
        return salary;
    }
}
