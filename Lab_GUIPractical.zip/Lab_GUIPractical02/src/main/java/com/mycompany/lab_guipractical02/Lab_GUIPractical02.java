
package com.mycompany.lab_guipractical02;

public class Lab_GUIPractical02 
{

    public static void main(String[] args)
    {
        CheckCommand c=new CheckCommand();
        c.show();
    }
}
