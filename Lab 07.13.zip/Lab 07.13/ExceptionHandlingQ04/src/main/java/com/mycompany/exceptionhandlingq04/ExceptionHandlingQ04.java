
package com.mycompany.exceptionhandlingq04;

public class ExceptionHandlingQ04
{

    public static void main(String[] args)
    {
        
    }
}
