
package com.mycompany.bankaccount;

public class SavingsAccount extends BAccount
{
    private static final double SAVING_INTEREST_RATE=0.12;
    
     @Override
   
    public void calculateInterest()
    {
     double Interest= SAVING_INTEREST_RATE*getBalance();
        System.out.println("Saving interest is: "+Interest);
    }
}

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
               