
package com.mycompany.labquestion1;

public class LabQuestion1 
{

    public static void main(String[] args)
    {
        CylindricalContainer c=new CylindricalContainer(20,10);
        System.out.println("Volume is "+c.volume());
    }
}
