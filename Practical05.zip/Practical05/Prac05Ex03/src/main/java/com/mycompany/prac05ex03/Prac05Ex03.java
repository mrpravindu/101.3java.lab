
package com.mycompany.prac05ex03;

public class Prac05Ex03 
{

    public static void main(String[] args) 
    {
        
    }
}
