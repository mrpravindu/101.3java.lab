
package com.mycompany.prac05ex02;

public class Lecturer implements Speaker
{
    public void speak()
    {
        System.out.println("Hello, I am a Lecturer");
    }
}
