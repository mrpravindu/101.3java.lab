
package com.mycompany.lab_guipractical01;

public class Lab_GUIPractical01 
{

    public static void main(String[] args) 
    {
        ColorChange c=new ColorChange();
        c.show();
    }
}
